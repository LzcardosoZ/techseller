package br.com.techseller.techsellers.service;

import br.com.techseller.techsellers.entity.Cliente;
import br.com.techseller.techsellers.entity.Endereco;
import br.com.techseller.techsellers.repository.ClienteRepository;
import br.com.techseller.techsellers.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

@Service
public class ClienteServiceImpl implements ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public Cliente cadastrarCliente(Cliente cliente) {
        if (emailExiste(cliente.getEmail())) {
            throw new IllegalArgumentException("E-mail já cadastrado");
        }
        if (cpfExiste(cliente.getCpf())) {
            throw new IllegalArgumentException("CPF já cadastrado");
        }

        // Criptografar a senha
        cliente.setSenha(passwordEncoder.encode(cliente.getSenha()));

        // Validar CEP e preencher endereço de faturamento
        Endereco enderecoFaturamento = validarCep(cliente.getEnderecoFaturamento().getCep());
        cliente.setEnderecoFaturamento(enderecoFaturamento);

        // Validar e preencher endereços de entrega
        for (int i = 0; i < cliente.getEnderecosEntrega().size(); i++) {
            Endereco enderecoEntrega = validarCep(cliente.getEnderecosEntrega().get(i).getCep());
            cliente.getEnderecosEntrega().set(i, enderecoEntrega);
        }

        return clienteRepository.save(cliente);
    }

    @Override
    public boolean emailExiste(String email) {
        return clienteRepository.existsByEmail(email);
    }

    @Override
    public boolean cpfExiste(String cpf) {
        return clienteRepository.existsByCpf(cpf);
    }

    @Override
    public Optional<Cliente> buscarPorEmail(String email) {
        return clienteRepository.findByEmail(email);
    }

    @Override
    public boolean emailJaCadastrado(String email) {
        return false;
    }

    private Endereco validarCep(String cep) {
        if (cep == null || cep.isBlank()) {
            throw new IllegalArgumentException("CEP não pode ser vazio");
        }

        // Remove formatação do CEP
        String cepNumerico = cep.replaceAll("[^0-9]", "");

        if (cepNumerico.length() != 8) {
            throw new IllegalArgumentException("CEP deve conter 8 dígitos");
        }

        RestTemplate restTemplate = new RestTemplate();
        String url = "https://viacep.com.br/ws/" + cepNumerico + "/json/";

        try {
            ResponseEntity<Endereco> response = restTemplate.getForEntity(url, Endereco.class);

            if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
                throw new IllegalArgumentException("CEP não encontrado");
            }

            Endereco endereco = response.getBody();
            endereco.setCep(cep); // Mantém a formatação original

            return endereco;
        } catch (HttpClientErrorException e) {
            throw new IllegalArgumentException("Erro ao consultar CEP: " + e.getMessage());
        } catch (Exception e) {
            throw new IllegalArgumentException("Serviço de CEP indisponível no momento");
        }
    }

}