package br.com.techseller.techsellers.enums;

public enum TipoFrete {
    MUNICIPAL,
    ESTADUAL,
    NACIONAL
}
