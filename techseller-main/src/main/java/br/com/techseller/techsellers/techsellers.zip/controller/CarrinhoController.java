package br.com.techseller.techsellers.controller;

import br.com.techseller.techsellers.entity.Carrinho;
import br.com.techseller.techsellers.enums.TipoFrete;
import br.com.techseller.techsellers.service.CarrinhoService;
import br.com.techseller.techsellers.service.ProdutoService;
import br.com.techseller.techsellers.utils.FreteUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;

@Controller
@RequestMapping("/carrinho")
@SessionAttributes("carrinho")
public class CarrinhoController {

    private final CarrinhoService carrinhoService;
    private final ProdutoService produtoService;

    @Autowired
    public CarrinhoController(CarrinhoService carrinhoService, ProdutoService produtoService) {
        this.carrinhoService = carrinhoService;
        this.produtoService = produtoService;
    }

    @ModelAttribute("carrinho")
    public Carrinho getCarrinho() {
        return new Carrinho();
    }

    @PostMapping("/adicionar")
    public String adicionarItem(@RequestParam Long produtoId,
                                @ModelAttribute Carrinho carrinho,
                                RedirectAttributes redirectAttributes) {
        try {
            carrinhoService.adicionarItem(carrinho, produtoId, 1);
            redirectAttributes.addFlashAttribute("success", "Produto adicionado ao carrinho");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/loja";
    }

    @PostMapping("/atualizar")
    public String atualizarQuantidade(@RequestParam Long produtoId,
                                      @RequestParam int quantidade,
                                      @ModelAttribute Carrinho carrinho,
                                      RedirectAttributes redirectAttributes) {
        try {
            carrinhoService.atualizarQuantidade(carrinho, produtoId, quantidade);
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/carrinho";
    }

    @PostMapping("/remover")
    public String removerItem(@RequestParam Long produtoId,
                              @ModelAttribute Carrinho carrinho) {
        carrinhoService.removerItem(carrinho, produtoId);
        return "redirect:/carrinho";
    }

    @GetMapping
    public String verCarrinho(@ModelAttribute Carrinho carrinho, Model model) {
        model.addAttribute("total", carrinhoService.calcularTotal(carrinho));
        model.addAttribute("totalItens", carrinhoService.contarItens(carrinho));
        return "carrinho";
    }
    @PostMapping("/frete")
    public String escolherFrete(@RequestParam("tipoFrete") String tipoFreteStr,
                                @ModelAttribute("carrinho") Carrinho carrinho,
                                RedirectAttributes redirectAttributes) {

        try {
            TipoFrete tipoFrete = TipoFrete.valueOf(tipoFreteStr.toUpperCase());
            BigDecimal valorFrete = FreteUtil.calcularFrete(tipoFrete, carrinho.getTotal());

            carrinho.setValorFrete(valorFrete);
            redirectAttributes.addFlashAttribute("success", "Frete aplicado: R$ " + valorFrete);

        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", "Tipo de frete inválido.");
        }

        return "redirect:/carrinho";
    }

}