package br.com.techseller.techsellers.controller;

import br.com.techseller.techsellers.entity.Cliente;
import br.com.techseller.techsellers.entity.Endereco;
import br.com.techseller.techsellers.service.ClienteService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/clientes")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @GetMapping("/cadastro")
    public String mostrarFormCadastro(Model model) {
        Cliente cliente = new Cliente();
        cliente.setEnderecoFaturamento(new Endereco());

        List<Endereco> enderecosEntrega = new ArrayList<>();
        enderecosEntrega.add(new Endereco());
        cliente.setEnderecosEntrega(enderecosEntrega);

        model.addAttribute("cliente", cliente);
        model.addAttribute("generos", Arrays.asList("Masculino", "Feminino", "Outro"));
        return "cadastroCliente";
    }

    @PostMapping("/cadastrar")
    public String cadastrarCliente(@Valid @ModelAttribute Cliente cliente,
                                   BindingResult result,
                                   Model model) {
        model.addAttribute("generos", Arrays.asList("Masculino", "Feminino", "Outro"));

        if (result.hasErrors()) {
            return "cadastroCliente";
        }

        try {
            if (clienteService.emailJaCadastrado(cliente.getEmail())) {
                model.addAttribute("erroEmail", "Este e-mail já está em uso");
                return "cadastroCliente";
            }

            clienteService.cadastrarCliente(cliente);
            return "redirect:/login";

        } catch (IllegalArgumentException e) {
            model.addAttribute("erroCEP", e.getMessage());
            return "cadastroCliente";
        }
    }

}
